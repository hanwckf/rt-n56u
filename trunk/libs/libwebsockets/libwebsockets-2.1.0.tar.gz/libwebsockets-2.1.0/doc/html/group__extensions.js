var group__extensions =
[
    [ "lws_ext_options", "structlws__ext__options.html", [
      [ "name", "structlws__ext__options.html#a1769e4a9805bbdda227821e9578ddc7e", null ],
      [ "type", "structlws__ext__options.html#a7c4dbd62dbeba63a9d50d2306bd1cc61", null ]
    ] ],
    [ "lws_ext_option_arg", "structlws__ext__option__arg.html", [
      [ "len", "structlws__ext__option__arg.html#af37f0b6caa7735af51a1ac12b68d5bc5", null ],
      [ "option_index", "structlws__ext__option__arg.html#af57fffcfa253dfa8d98681ac1fb1785f", null ],
      [ "option_name", "structlws__ext__option__arg.html#a0a320c56b79271b8f059eeaad9423ac9", null ],
      [ "start", "structlws__ext__option__arg.html#a0b1f7b30c3ceaf5f1bf9d105c24568d1", null ]
    ] ],
    [ "lws_extension", "structlws__extension.html", [
      [ "callback", "structlws__extension.html#afa21f3b3c8c2c9212a276c52b680c3af", null ],
      [ "client_offer", "structlws__extension.html#a36b06c213aedb02bf9a402651751855b", null ],
      [ "name", "structlws__extension.html#a1e5018c883d85176f5c2152176843f9e", null ]
    ] ],
    [ "lws_extension_callback_function", "group__extensions.html#gaae7169b2cd346b34fa33d0250db2afd0", null ],
    [ "lws_ext_options_types", "group__extensions.html#gacc9f55936dc165257a2e1f7d47bce89e", [
      [ "EXTARG_NONE", "group__extensions.html#ggacc9f55936dc165257a2e1f7d47bce89eaabcf56c456c1ff6e81dc82586a16f14c", null ],
      [ "EXTARG_DEC", "group__extensions.html#ggacc9f55936dc165257a2e1f7d47bce89ea1c86adf924c8786a12bee9687094673e", null ],
      [ "EXTARG_OPT_DEC", "group__extensions.html#ggacc9f55936dc165257a2e1f7d47bce89ea5265abe3e1c3f64412f2affe7bffd880", null ]
    ] ],
    [ "lws_ext_parse_options", "group__extensions.html#ga6fb3e2c3dfb9d64dc87026a4e99c128b", null ],
    [ "lws_extension_callback_pm_deflate", "group__extensions.html#ga4cdbe42d872e21a448a947714d6c607e", null ],
    [ "lws_set_extension_option", "group__extensions.html#gae0e24e1768f83a7fb07896ce975704b9", null ]
];