var group__smtp =
[
    [ "lws_email", "structlws__email.html", [
      [ "content", "structlws__email.html#a6fff03c5a5d369a2aa3cab0c897b1bed", null ],
      [ "data", "structlws__email.html#add1341456045382c183f4c763bdea6bc", null ],
      [ "email_buf", "structlws__email.html#a8f34ec0643a817be67ef4276aeb7fb82", null ],
      [ "email_client", "structlws__email.html#a01f31934166dc6d01e8a375012f8ad1e", null ],
      [ "email_connect_req", "structlws__email.html#a5f53d4c5a1e34b0dcaa8787e2eabb1b3", null ],
      [ "email_connect_started", "structlws__email.html#a9747ca85597788c2d118d287df47b7c1", null ],
      [ "email_from", "structlws__email.html#af7f0ae934347d81071f63a963301f9e2", null ],
      [ "email_helo", "structlws__email.html#a939e5d7ee0339a16de73bde71ab4d4d9", null ],
      [ "email_smtp_ip", "structlws__email.html#a472ae23fc9fca6599e5c512bc21458d2", null ],
      [ "email_to", "structlws__email.html#a6453a8b92b3de6d2c2101af3edce685e", null ],
      [ "estate", "structlws__email.html#ac6115d3cbef2e8bac62cc00895bf5fd3", null ],
      [ "loop", "structlws__email.html#ab5fbf121195a8e67509c78a42cfbe168", null ],
      [ "max_content_size", "structlws__email.html#a7bbc1964889c984b3da723c86a210e05", null ],
      [ "on_get_body", "structlws__email.html#a2aff78c8e04db243052aa91b4d87e987", null ],
      [ "on_next", "structlws__email.html#ad8dc60353ee246d84dd59ec0591e9719", null ],
      [ "on_sent", "structlws__email.html#a39ef6263d58eb40cca417c8697b227d8", null ],
      [ "timeout_email", "structlws__email.html#a77723e2f2b940b1c879ef5e1cd88c2be", null ]
    ] ],
    [ "lwsgs_smtp_states", "group__smtp.html#ga116be79bf44f9dc2a97f46e051fe4dc0", [
      [ "LGSSMTP_IDLE", "group__smtp.html#gga116be79bf44f9dc2a97f46e051fe4dc0a29e5b0ecf75375b5a643faa3d6222b7c", null ],
      [ "LGSSMTP_CONNECTING", "group__smtp.html#gga116be79bf44f9dc2a97f46e051fe4dc0ab89442b7a3ca2b94c3cdcf33756eb933", null ],
      [ "LGSSMTP_CONNECTED", "group__smtp.html#gga116be79bf44f9dc2a97f46e051fe4dc0ab61778f70ecac007b334bb14942eb41d", null ],
      [ "LGSSMTP_SENT_HELO", "group__smtp.html#gga116be79bf44f9dc2a97f46e051fe4dc0a1dfec948a864205cec875f63cbe0d4ad", null ],
      [ "LGSSMTP_SENT_FROM", "group__smtp.html#gga116be79bf44f9dc2a97f46e051fe4dc0a929bb4623ff3f585108aba2a1b047fab", null ],
      [ "LGSSMTP_SENT_TO", "group__smtp.html#gga116be79bf44f9dc2a97f46e051fe4dc0aae20a0cb95b97a70f6b45d0ed2d5be83", null ],
      [ "LGSSMTP_SENT_DATA", "group__smtp.html#gga116be79bf44f9dc2a97f46e051fe4dc0a85e3c452950c09a79086bff4b9be5c14", null ],
      [ "LGSSMTP_SENT_BODY", "group__smtp.html#gga116be79bf44f9dc2a97f46e051fe4dc0a38fba41f28d754e38079b31418a86a69", null ],
      [ "LGSSMTP_SENT_QUIT", "group__smtp.html#gga116be79bf44f9dc2a97f46e051fe4dc0a2c2ed16ffc572326e3040684084b21d5", null ]
    ] ],
    [ "lws_email_check", "group__smtp.html#ga5e535e346d92a9daf00be33abf79d4eb", null ],
    [ "lws_email_destroy", "group__smtp.html#ga25298a5afc1074e13b2d5711a86432b2", null ],
    [ "lws_email_init", "group__smtp.html#ga77fc9b56a1bb39484844981ec375fc29", null ]
];