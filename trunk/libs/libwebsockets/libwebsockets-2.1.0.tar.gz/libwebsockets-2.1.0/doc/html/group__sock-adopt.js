var group__sock_adopt =
[
    [ "lws_adopt_socket", "group__sock-adopt.html#gabe71b7462afb21c767bdc67334f305af", null ],
    [ "lws_adopt_socket_readbuf", "group__sock-adopt.html#gab2d045df0f81afe00891aaed312d552b", null ]
];