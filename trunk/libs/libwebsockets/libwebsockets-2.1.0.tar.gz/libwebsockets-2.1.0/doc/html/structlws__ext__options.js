var structlws__ext__options =
[
    [ "name", "structlws__ext__options.html#a1769e4a9805bbdda227821e9578ddc7e", null ],
    [ "type", "structlws__ext__options.html#a7c4dbd62dbeba63a9d50d2306bd1cc61", null ]
];