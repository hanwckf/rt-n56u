var structlws__http__mount =
[
    [ "auth_mask", "structlws__http__mount.html#a614364c770b0bd4db464ad65cddab477", null ],
    [ "cache_intermediaries", "structlws__http__mount.html#aabec1a326780aafe11b977000983be0c", null ],
    [ "cache_max_age", "structlws__http__mount.html#a4283e30ea89d27ae7d061ad760d1d146", null ],
    [ "cache_reusable", "structlws__http__mount.html#a8316dd183ffbef50419a5a4968d35d84", null ],
    [ "cache_revalidate", "structlws__http__mount.html#ae137203040c6153694bd88a708da5395", null ],
    [ "cgi_timeout", "structlws__http__mount.html#a4a7239d6d4c03986e6e1a72abb6c83aa", null ],
    [ "cgienv", "structlws__http__mount.html#ae7b5c0f4c5408061e6ea3a8d281f45af", null ],
    [ "def", "structlws__http__mount.html#ae90d1efe7178199fad39de2926902ee4", null ],
    [ "extra_mimetypes", "structlws__http__mount.html#a4437423df85ee3dbcae0e15974c89ec7", null ],
    [ "interpret", "structlws__http__mount.html#a11ea62b952710d59733dbcf9794a5773", null ],
    [ "mount_next", "structlws__http__mount.html#a0109baf93f23c07c824c997c3533ee44", null ],
    [ "mountpoint", "structlws__http__mount.html#aa2391bfcada0b7a290b3c6651f64586c", null ],
    [ "mountpoint_len", "structlws__http__mount.html#ac8489b60b8f969eb19c9abbdeac90743", null ],
    [ "origin", "structlws__http__mount.html#a21d86fd6043ec00e121ababbc29af39a", null ],
    [ "origin_protocol", "structlws__http__mount.html#a6a9b1492a0b9749e39bd19932717a0b7", null ],
    [ "protocol", "structlws__http__mount.html#a05347d92c3d379809564bd4f3eab259b", null ]
];