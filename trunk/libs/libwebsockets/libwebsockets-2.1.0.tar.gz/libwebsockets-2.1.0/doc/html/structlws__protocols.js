var structlws__protocols =
[
    [ "callback", "structlws__protocols.html#acabf94c1a9bfe7be0387fbb0e0c56b2d", null ],
    [ "id", "structlws__protocols.html#a6b632018590c2b1bbe43fbab6d5e6fac", null ],
    [ "name", "structlws__protocols.html#a0e63edb457a613c3fa4271e0a8f19624", null ],
    [ "per_session_data_size", "structlws__protocols.html#a9bbd85f591ffb4259711cb5acbb05bea", null ],
    [ "rx_buffer_size", "structlws__protocols.html#a0d1d4996d81b2f5e125bcec981e461c5", null ],
    [ "user", "structlws__protocols.html#a3cbd903ad076736ae934a54cae36580e", null ]
];