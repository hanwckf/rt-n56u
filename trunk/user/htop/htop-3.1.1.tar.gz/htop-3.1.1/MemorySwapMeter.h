#ifndef HEADER_MemorySwapMeter
#define HEADER_MemorySwapMeter
/*
htop - MemorySwapMeter.h
(C) 2021 htop dev team
Released under the GNU GPLv2+, see the COPYING file
in the source distribution for its full text.
*/

#include "Meter.h"


extern const MeterClass MemorySwapMeter_class;

#endif
