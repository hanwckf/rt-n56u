#ifndef HELLO_H
#define HELLO_H

extern const struct GlobalConfig {
	const char *package_name;
	const char *package_version;
	const char *locale_dir;
} g_config;

#endif//HELLO_H
