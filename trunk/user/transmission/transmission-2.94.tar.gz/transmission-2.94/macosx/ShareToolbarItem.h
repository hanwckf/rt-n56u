//
//  ShareButtonToolbarItem.h
//  Transmission
//
//  Created by Mitchell Livingston on 1/8/14.
//  Copyright (c) 2014 The Transmission Project. All rights reserved.
//

#import "ButtonToolbarItem.h"

@interface ShareToolbarItem : ButtonToolbarItem

@end
