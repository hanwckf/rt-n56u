# Building the inlined html

install [Yarn](https://yarnpkg.com), then run the following commands:

```bash
yarn
yarn run build
```

this will compile the inlined html to `../src/index.html`.