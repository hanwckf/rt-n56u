# Building the man page

```bash
go get github.com/cpuguy83/go-md2man
go-md2man < ttyd.man.md  > ttyd.1
```