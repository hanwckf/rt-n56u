// Package crypto provides common crypto libraries for V2Ray.
package crypto

//go:generate go run github.com/v2fly/v2ray-core/v4/common/errors/errorgen
