
#ifndef NS_NAME_H_
#define NS_NAME_H_

int
ns_name_uncompress_vlmcsd(uint8_t *msg, uint8_t *eom, uint8_t *src,
		   char *dst, size_t dstsiz);

#endif /* NS_NAME_H_ */
